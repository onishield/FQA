<div class='footer'>
  <div id="wrapper" style="background-color: #bfbfbf; height: 80px;">
    <h5 style="float:left;margin-left: 20px;margin-top: 20px;">&copy; 2017 CAT TELECOM PUBLIC COMPANY LIMITED. All rights reserved.</h5>
    <h5 style="float:right;margin-right: 20px;margin-top: 20px;">Thanarkom Khunboonchan | Trainee<br>Wongsathorn Charoenkul &nbsp&nbsp| Trainee</h5>
  </div>
</div>
